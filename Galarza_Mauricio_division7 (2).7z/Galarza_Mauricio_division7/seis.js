function mostrar()
{
var hora;

hora = parseInt(document.getElementById("laHora").value);

switch(hora)
{
    case hora:
    if(hora > 24 || hora < 1)
    {
        hora = prompt("hora invalida, vuelva a ingresarla....");
    }
    else
    {
        if(hora >= 6 && hora <= 11)
        {
            alert("es de mañana");
        }
        else if(hora >= 12 && hora <= 19)
        {
            alert("es de tarde");
        }
        else
        {
            alert("es de noche");
            if(hora > 19)
            {
                alert("es denoche a dormir");
            }
        }
    }
}
}
