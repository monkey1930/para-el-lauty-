function mostrar()
{
    var num, letra, Cpares = 0, Cimpares = 0, Cceros = 0, sumaPositivos = 0, sumaNegativos = 0, promedio, Cpositivos = 0,flag = true, numMinimo, letraMin, numMaximo, letraMax;  

    do
    {
        num = parseInt(prompt("Ingrese un numero..."));
        
        while(num > 100 || num < -100 )
        {
            num = parseInt(prompt("numero invalido, vuelva a ingresar un numero..."));
        }
        letra = prompt("ingrese una letra...");

        if(num == 0)
        {
            Cceros ++;
        }
        else if(num != 0)
        {
            if(num % 2 == 0)
            {
                Cpares ++;
            }
            else
            {
                Cimpares ++;
            }
            if(num > 0)
            {
                Cpositivos ++;
                sumaPositivos += num;
                promedio = sumaPositivos / Cpositivos;
            }
            else
            {
                sumaNegativos += num;
            }


        }

        if(flag || num < numMinimo)
        {
            numMinimo = num;
            letraMin = letra;
        }
        if(flag || num < numMaximo)
        {
            numMaximo = num;
            letraMin = letra;
        }

        flag = false;

        




    }while(confirm())
    
    document.write("a) La cantidad de números pares. es ..." + Cpares + "</br>" +
    "b) La cantidad de números impares.es..." + Cimpares+ "</br>" + 
    "c) La cantidad de ceros. es..." + Cceros+ "</br>" + 
    "d) El promedio de todos los números positivos ingresados. es..." + promedio+ "</br>" + 
    "e) La suma de todos los números negativos.es .." +sumaNegativos + "</br>" +
    "f) El número y la letra del máximo y el mínimo.es..." + letraMin + " "+ numMinimo+ " " + letraMax+ " " + numMaximo );


}
