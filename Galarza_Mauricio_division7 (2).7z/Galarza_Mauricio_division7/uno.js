
function mostrar()
{
var dato, perimetro;

dato = parseInt(prompt("dame un lado del triangulo equilatero..."));
perimetro = dato * 3;
alert("El perimetro del triangulo equilatero es: " + perimetro);
}
