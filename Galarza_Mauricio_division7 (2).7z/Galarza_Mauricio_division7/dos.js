function mostrar()
{
  var peso2, peso1, name1, name2, promedio, suma;


  name1 = prompt("digame el nombre de uno de los dos...");
  name2 = prompt("digame el nombre del otro...");
  peso1 = parseInt(prompt("cuanto pesa.." + name1));
  peso2 = parseInt(prompt("cuanto pesa.." + name2));
  
  suma = peso1 + peso2;
  promedio = (suma / 2);

  document.write(" ustedes se llaman " + name1 + " y " + name2 + "</br>" +
   "pesan " + peso1 + " y " + peso2 + " kilos, " + "</br>" +
  " que sumados son " + suma + " kilos" + "</br>" +
  " y el promedio de peso " + promedio + " kilos");
}
