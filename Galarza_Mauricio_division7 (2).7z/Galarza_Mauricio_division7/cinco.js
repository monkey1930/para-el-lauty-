function mostrar()
{
var continente, dias, monto,montoFinal,mensaje = "";

continente = document.getElementById("Marca").value;
dias = parseInt(prompt("ingrese la cantidad de dias que prefiera...."));

monto = dias * 100;

switch(continente)
{
    case "América":
    mensaje =( mensaje + "En América tiene un 50% de descuento," + "</br> " +
    "quedando el precio final en... $" + (monto - (monto /100 *50)) + "</br> " +
    "ademas si paga por débito se le agrega un 10% mas de descuento, quedando en... $" +(monto - (monto /100 *60)))  
    break;
    case "África":
    mensaje =( mensaje + "En África tiene un 60% de descuento," + "</br> " +
    "quedando el precio final en... $" + (monto - (monto /100 *60)) + "</br> " +
    "ademas si paga por mercadoPago o efectivo se le agrega un 15% mas de descuento, quedando en... $" +(monto - (monto /100 *75)))  
    break;
    case "Europa":
    mensaje =( mensaje + "En Europa tiene un 20% de descuento," + "</br> " +
    "quedando el precio final en... $" + (monto - (monto /100 *60)) + "</br> " +
    "ademas si paga por débito se le agrega un 15% mas de descuento, quedando en... $" +(monto - (monto /100 *35)) + "</br> " + 
    "por mercadoPago un 10%, quedando en... $" + (monto - (monto /100 *30))+ "</br> " +
    "y cualquier otro medio un 5%, quedando en... $" + (monto - (monto /100 *25)))
    break;
    default:

    mesaje = (mensaje + " tiene un recargo del 20%, quedando en... $" + (monto + (monto /100 *20)))



}
document.write(mensaje);
}
