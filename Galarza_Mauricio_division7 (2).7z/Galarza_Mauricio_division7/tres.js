function mostrar()
{
    var precio, descuento, pfinal;

    precio = parseInt(prompt("dame el precio", "$XXXX...."));
    descuento = parseInt(prompt("dame el procentaje de descuento...","%XXXX...."));

    pfinal = precio - (precio / 100 * descuento);

    document.getElementById("elPrecioFinal").value = "El precio final es... $" + pfinal;
}
