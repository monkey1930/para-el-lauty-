function mostrar()
{
    var alturas, sexo, suma = 0, promedio, alturamin, sexoDelMin,CmujeresAltas = 0, contador = 0, flag = true;


    while(contador <= 5)
    {   
        alturas = parseInt(prompt("Ingrese la altura en cm por favor","ejemplo: 190, 175, 150, etc..."));
        sexo = prompt("ingrese el sexo de la persona...","ejemplo: *f* o *m* ");

        while(alturas > 250 || alturas < 0)
        {
            alturas = parseInt(prompt("altura invalida, vuelva a ingresar la altura..."));
        }
        while(sexo != "f" && sexo != "m")
        {
            sexo = prompt("sexo no valido, vuelva a ingresarlo....","ejemplo f o m...");
        }
        suma += alturas;
        promedio = suma / contador;

        if(flag || alturas < alturamin)
        {
            alturamin = alturas;
            sexoDelMin = sexo;
        }
        if(alturas > 190 && sexo == "f")
        {
            CmujeresAltas ++;
        }
        flag = false;
        contador ++;
    }

    alert("a) El promedio de las alturas totales. Es... " + promedio);
    alert("b) La altura más baja y el sexo de esa persona. Es... " + alturamin + " y el sexo de esa persona es..." + sexoDelMin);
    alert("c) La cantidad de muheres que su altura supere los 190 centimetros. Es de...." + CmujeresAltas);
/*use 3 alerts, porque se me hace mucho mas ordenado todo*/


}
