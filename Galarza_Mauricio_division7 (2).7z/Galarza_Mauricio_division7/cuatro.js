function mostrar()
{
    var num1, num2, resultado;

    num1 = prompt("dame un numero....");
    num2 = prompt("dame otro numero....");

    if(num1 == num2)
    {
        resultado = num1 + num2;
    }
    else
    {
        num1 = parseInt(num1);
        num2 = parseInt(num2);
    }

    if(num1 > num2)
    {
        resultado = num1 - num2;
        if(resultado > 10)
        {
            alert("la resta es " + resultado  + " y superó el 10");
        }
        else
        {
            alert("el resultado es: " + resultado);
        }
    }
    else
    {
        resultado = num1 + num2;
        alert("el resultado es: " + resultado);
    }
    
}
